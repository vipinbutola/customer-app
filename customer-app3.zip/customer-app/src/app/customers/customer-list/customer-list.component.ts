import { Component, OnInit } from '@angular/core';
import { GlobalvarsService } from '../../globalvars.service';
import { CustomersService } from "../customers.service";
@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  users:any;

  constructor( public GlobalvarsService:GlobalvarsService, public CustomersService: CustomersService ) { }

  ngOnInit() {
  this.getUsersList();


  }

   getUsersList(){
    this.CustomersService.getEmployees().subscribe(data=> {
      console.log(data);
      this.users = data;
    })

  }

}
