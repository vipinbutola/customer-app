import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { GlobalvarsService } from "../globalvars.service";;
@Injectable({
  providedIn: 'root'
})
export class CustomersService {
   newVar= "test"; 
  constructor(private http: HttpClient, private GlobalvarsService:GlobalvarsService) { }

  getEmployees(){
    return this.http.get(this.GlobalvarsService.globaleurl)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  handleError(handleError: any): any {
    throw new Error("Method not implemented.");
  }

}
